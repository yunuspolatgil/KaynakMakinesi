﻿using KaynakMakinesi.Core.Tags;   // <-- ÖNEMLİ
using KaynakMakinesi.Infrastructure.Db;
using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace KaynakMakinesi.Infrastructure.Tags
{
    public sealed class SqliteTagRepository : ITagRepository
    {
        private readonly SqliteDb _db;

        public SqliteTagRepository(SqliteDb db) { _db = db; }

        public void EnsureSchema()
        {
            using (var con = (SQLiteConnection)_db.Open())
            using (var cmd = con.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Tags(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Address TEXT NOT NULL,
    Type TEXT NOT NULL,
    GroupName TEXT NULL,
    Description TEXT NULL,
    PollMs INTEGER NOT NULL,
    ReadOnly INTEGER NOT NULL,
    UpdatedAt TEXT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS IX_Tags_Name ON Tags(Name);";
                cmd.ExecuteNonQuery();
            }
        }

        public List<TagDef> ListAll()
        {
            var list = new List<TagDef>();
            using (var con = (SQLiteConnection)_db.Open())
            using (var cmd = con.CreateCommand())
            {
                cmd.CommandText = @"SELECT Id, Name, Address, Type, GroupName, Description, PollMs, ReadOnly
                                    FROM Tags ORDER BY Name;";
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new TagDef
                        {
                            Id = r.GetInt64(0),
                            Name = r.GetString(1),
                            Address = r.GetString(2),
                            Type = r.GetString(3),
                            GroupName = r.IsDBNull(4) ? "" : r.GetString(4),
                            Description = r.IsDBNull(5) ? "" : r.GetString(5),
                            PollMs = r.GetInt32(6),
                            ReadOnly = r.GetInt32(7) == 1
                        });
                    }
                }
            }
            return list;
        }

        public void UpsertMany(IEnumerable<TagDef> tags)
        {
            using (var con = (SQLiteConnection)_db.Open())
            using (var tx = con.BeginTransaction())
            using (var cmd = con.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
INSERT INTO Tags(Name, Address, Type, GroupName, Description, PollMs, ReadOnly, UpdatedAt)
VALUES(@Name, @Address, @Type, @GroupName, @Description, @PollMs, @ReadOnly, @UpdatedAt)
ON CONFLICT(Name) DO UPDATE SET
    Address=excluded.Address,
    Type=excluded.Type,
    GroupName=excluded.GroupName,
    Description=excluded.Description,
    PollMs=excluded.PollMs,
    ReadOnly=excluded.ReadOnly,
    UpdatedAt=excluded.UpdatedAt;";

                cmd.Parameters.Add(new SQLiteParameter("@Name"));
                cmd.Parameters.Add(new SQLiteParameter("@Address"));
                cmd.Parameters.Add(new SQLiteParameter("@Type"));
                cmd.Parameters.Add(new SQLiteParameter("@GroupName"));
                cmd.Parameters.Add(new SQLiteParameter("@Description"));
                cmd.Parameters.Add(new SQLiteParameter("@PollMs"));
                cmd.Parameters.Add(new SQLiteParameter("@ReadOnly"));
                cmd.Parameters.Add(new SQLiteParameter("@UpdatedAt"));

                foreach (var t in tags)
                {
                    cmd.Parameters["@Name"].Value = t.Name ?? "";
                    cmd.Parameters["@Address"].Value = t.Address ?? "";
                    cmd.Parameters["@Type"].Value = t.Type ?? "";
                    cmd.Parameters["@GroupName"].Value = t.GroupName ?? "";
                    cmd.Parameters["@Description"].Value = t.Description ?? "";
                    cmd.Parameters["@PollMs"].Value = t.PollMs;
                    cmd.Parameters["@ReadOnly"].Value = t.ReadOnly ? 1 : 0;
                    cmd.Parameters["@UpdatedAt"].Value = DateTime.Now.ToString("s");
                    cmd.ExecuteNonQuery();
                }

                tx.Commit();
            }
        }

        public void DeleteByName(string name)
        {
            using (var con = (SQLiteConnection)_db.Open())
            using (var cmd = con.CreateCommand())
            {
                cmd.CommandText = "DELETE FROM Tags WHERE Name=@Name;";
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
